#Nikola Kilibarda, Adam Casto, Poean Lu

from flask import Flask, render_template, request, redirect
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://csc315sm20:csc315sm20@localhost/7dbs'
db = SQLAlchemy(app)
###############################################################
class inventory(db.Model):
      book_id = db.Column(db.Integer, primary_key=True)
    #  isbn = db.Column(db.String(13), nullable=False)
      isbn = db.Column(db.String(13), db.ForeignKey('book.isbn'),nullable=False)
      book = db.relationship('book', primaryjoin='inventory.isbn == book.isbn')
def __repr__(self):
        return 'Book ID' + str(self.book_id)
###############################################################
class book(db.Model):
      isbn = db.Column(db.String(13), primary_key=True)
      author = db.Column(db.String(50),nullable=False)
      title = db.Column(db.String(50),nullable=False)
      virtual = db.Column(db.String(5),nullable=False)
      genre = db.Column(db.String(50),nullable=False)

def __repr__(self):
    return 'ISBN:' +   self.isbn
################################################################
class customer(db.Model):
      customer_id = db.Column(db.Integer, primary_key=True)
      name = db.Column(db.String(255),nullable=False)
      address = db.Column(db.String(255),nullable=False)
      phone = db.Column(db.String(10),nullable=False)

def __repr__(self):
        return 'Member ID' + str(self.customer_id)
################################################################
class borrows(db.Model):
      borrow_id = db.Column(db.Integer, primary_key=True)
      customer_id = db.Column(db.Integer,db.ForeignKey('customer.customer_id'),nullable=False)
      book_id = db.Column(db.String(13), db.ForeignKey('inventory.book_id'), nullable=False)
      rent_date = db.Column(db.String(15),nullable=False)
      due_date = db.Column(db.String(15),nullable=False)
      customer = db.relationship('customer', primaryjoin='borrows.customer_id == customer.customer_id')
      inventory = db.relationship('inventory', primaryjoin='borrows.book_id == inventory.book_id')
def __repr__(self):
        return 'Borrow ID' + str(self.borrow_id)


################################################################
@app.route("/")
def index():
    return render_template('index.html')

@app.route('/books', methods=['GET','POST'])
def Book():

    if request.method == 'POST':
        post_isbn = request.form['isbn']
        post_author = request.form['author']
        post_BookTitle = request.form['title']
        post_Virtual = request.form['virtual']
        post_BookGenre = request.form['genre']
        new_book = book(isbn=post_isbn, author=post_author, title=post_BookTitle, virtual=post_Virtual, genre=post_BookGenre)
        db.session.add(new_book)
        db.session.commit()
        return redirect('/books')
    else:
        all_books = book.query.all()
        return render_template('books.html',books=all_books)
######################################################################
@app.route('/borrows', methods=['GET','POST'])
def Borrows():

    if request.method == 'POST':
        post_customer_id = request.form['customer_id']
        post_book_id = request.form['book_id']
        post_rent_date = request.form['rent_date']
        post_due_date = request.form['due_date']
        new_borrow = borrows(customer_id=post_customer_id, book_id=post_book_id, rent_date=post_rent_date, due_date=post_due_date)
        db.session.add(new_borrow)
        db.session.commit()
        return redirect('/borrows')
    else:
       # all_borrows = borrows.query.all()
        all_borrows = borrows.query.join(customer).all()
        return render_template('borrows.html',borrows=all_borrows)


@app.route('/borrows/delete/<int:borrow_id>')
def delete_Borrow(borrow_id):
    Borrow = borrows.query.get_or_404(borrow_id)
    db.session.delete(Borrow)
    db.session.commit()
    return redirect('/borrows')

@app.route('/borrows/edit/<int:borrow_id>', methods=['GET', 'POST'])
def edit_Borrow(borrow_id):

    Borrow = borrows.query.get_or_404(borrow_id)

    if request.method == 'POST':
       Borrow.borrow_id=request.form['borrow_id']
       Borrow.customer_id=request.form['customer_id']
       Borrow.book_id=request.form['book_id']
       Borrow.rent_date=request.form['rent_date']
       Borrow.due_date=request.form['due_date']
       db.session.commit();
       return redirect('/borrows')
    else:
       return render_template('borrows_edit.html', Borrow=Borrow)



######################################################################
@app.route('/inventory', methods=['GET','POST'])
def Inventory():

    if request.method == 'POST':
        #post_book_id = request.form['book_id']
        post_isbn = request.form['isbn']
        new_inventory = inventory(isbn=post_isbn)
        #new_inventory = inventory(book_id=post_book_id,isbn=post_isbn)
        db.session.add(new_inventory)
        db.session.commit()
        return redirect('/inventory')
    else:
        #all_inventory = inventory.query.all()
        all_inventory = inventory.query.join(book).all()
        return render_template('inventory.html',inventories=all_inventory)


@app.route('/inventory/delete/<int:book_id>')
def delete_Inventory(book_id):
    Inventory = inventory.query.get_or_404(book_id)
    db.session.delete(Inventory)
    db.session.commit()
    return redirect('/inventory')

@app.route('/inventory/edit/<int:book_id>', methods=['GET', 'POST'])
def edit_Inventory(book_id):

    Inventory = inventory.query.get_or_404(book_id)

    if request.method == 'POST':
       inventory.book_id=request.form['book_id']
       inventory.isbn=request.form['isbn']
       db.session.commit();
       return redirect('/inventory')
    else:
       return render_template('inventory_edit.html', Inventory=Inventory)



######################################################################################

@app.route('/search_title', methods=['GET','POST'])
def search_title():

 if request.method == 'POST':
    post_BookTitle=request.form['title']
    result_books = book.query.filter(book.title.contains(post_BookTitle)).all()
    return render_template('search_title.html',books=result_books)
 else:
    result_books =""
    return render_template('search_title.html',books=result_books)
######################################################################################

@app.route('/search_inventory', methods=['GET','POST'])
def search_inventory():

 if request.method == 'POST':
    post_BookTitle=request.form['title']
    result_books = inventory.query.join(book).filter(book.title.contains(post_BookTitle)).all()
    return render_template('search_inventory.html',books=result_books)
 else:
    result_books =""
    return render_template('search_inventory.html',books=result_books)


   
#####################################################################
@app.route('/search_genre', methods=['GET','POST'])
def search_genre():

 if request.method == 'POST':
    post_BookGenre=request.form['genre']
    result_books = book.query.filter(book.genre.contains(post_BookGenre)).all()
    return render_template('search_genre.html',books=result_books)
 else:
    result_books =""
    return render_template('search_genre.html',books=result_books)


#####################################################################

@app.route('/books/delete/<isbn>')
def delete(isbn):
    dbook = book.query.get_or_404(isbn)
    db.session.delete(dbook)
    db.session.commit()
    return redirect('/books')


@app.route('/books/edit/<isbn>', methods=['GET', 'POST'])
def edit(isbn):

   ebook = book.query.get_or_404(isbn)

   if request.method == 'POST':
       ebook.isbn=request.form['isbn']
       ebook.author=request.form['author']
       ebook.title=request.form['title']
       ebook.virtual=request.form['virtual']
       ebook.genre=request.form['genre']
       db.session.commit();
       return redirect('/books')
   else:
       return render_template('edit.html', ebook=ebook)
########################################################################
@app.route('/members', methods=['GET','POST'])
def member():

    if request.method == 'POST':
        post_name = request.form['name']
        post_address = request.form['address']
        post_phone = request.form['phone']
        new_member = customer(name=post_name, address=post_address, phone=post_phone)
        db.session.add(new_member)
        db.session.commit()
        return redirect('/members')
    else:
        all_members = customer.query.all()
        return render_template('members.html',members=all_members)


@app.route('/members/delete/<int:customer_id>')
def delete_member(customer_id):
    member = customer.query.get_or_404(customer_id)
    db.session.delete(member)
    db.session.commit()
    return redirect('/members')


@app.route('/members/edit/<int:customer_id>', methods=['GET', 'POST'])
def edit_member(customer_id):

    member = customer.query.get_or_404(customer_id)

    if request.method == 'POST':
       member.name=request.form['name']
       member.address=request.form['address']
       member.phone=request.form['phone']
       db.session.commit();
       return redirect('/members')
    else:
       return render_template('member_edit.html', member=member)


@app.route('/search_member', methods=['GET','POST'])
def search_member():

 if request.method == 'POST':
    post_Name=request.form['name']
    result_member = customer.query.filter(customer.name.contains(post_Name)).all()
    return render_template('search_member.html',members=result_member)
 else:
    result_member =""
    return render_template('search_member.html',members=result_member)


######################################################################

@app.route("/home/<string:name>")
def hello_world(name):
    return "Hello "+name

if __name__ == "__main__":
    app.run()
